#include <QCoreApplication>
#include <QDebug>

// Include Eigen Solver
#include <eigen3/Eigen/Eigen>
#include <eigen3/Eigen/Sparse>
#include <eigen3/Eigen/SparseQR>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/IterativeLinearSolvers>

// Include vector
#include <vector>

using namespace Eigen;
using namespace std;

// Define triplet structure for solving
typedef Triplet<double> T;
typedef SparseMatrix<double, Eigen::ColMajor> SpMat;

// Lenght of the  field
int lenght = 5;

// Field and constraints data structure
double * field;
bool * constrained;


void printSolution(VectorXd x)
{
    qDebug() << "Solution vector";

    for(int i = 0; i < lenght; i++)
    {
        qDebug() << i << "[" << x[i] << "]" ;
    }
}

void setUp()
{
    // Create and init the field
    field = new double[lenght];
    constrained = new bool[lenght];

    for(int i = 0; i < lenght; i++)
    {
        field[i] = 0;
        constrained[i] = false;
    }
}


void addConstraints()
{
    // Some hardcoded constraints
    field[0] = 0;
    constrained[0] = true;

    field[lenght-1] = 255;
    constrained[lenght-1] = true;
}


void setUpNormalSystem(SpMat & A,  VectorXd & b)
{
    // Triplets init
    vector<T>  * tripletList;
    tripletList = new vector<T>;
    tripletList->reserve(lenght*2);

    // Values for b
    QList<QPair<int,double> > b_values;
    int rowInA = 0;

    // Set up the constraints
    // For every cell in the field
    for(int i = 0; i < lenght; i++)
    {
        // c_i
        int c_i = i;
        // c_j
        int c_j = i+1;

        // Handle Boundary
        // If I am on the right edge, then:
        if(i==lenght-1)
        {
            c_j = c_i;
        }

        // Add smooth constraints to A
        //(cj-ci)
        tripletList->push_back(T(rowInA,c_i,-1));
        tripletList->push_back(T(rowInA,c_j,1));
        rowInA++;

        // Add scalar constraints
        if(constrained[i])
        {
            tripletList->push_back(T(rowInA,c_i,1000));
            b_values.push_back(QPair<int,double>(rowInA,1000*field[i]));
            rowInA++;
        }
    }

    // Resize A before setting it from triplets (A is empty and not created at this point)
    A.resize(rowInA,lenght);
    A.reserve(VectorXd::Constant(lenght,2));
    A.setFromTriplets(tripletList->begin(),tripletList->end());
    A.makeCompressed();

    // Also resize b before setting it from the b_values list
    b.resize(rowInA);
    b.setZero();

    // Copy values from b_values at b
    for(int i = 0; i < b_values.size();i++)
    {
        b(b_values.at(i).first) = b_values.at(i).second;
    }
}

void solveWithNormalEquation()
{
    qDebug() << "Solving with normal equations";

    // A and b
    SpMat A;
    VectorXd b;

    // Set up system
    setUpNormalSystem(A,b);

    // Cholesky Decomposition
    SimplicialCholesky<SpMat> chol(A.transpose() * A);
    //ConjugateGradient<SpMat> cg(A_final);
    //cg.setTolerance(0.0001);

    // Check success
    if(chol.info()!=Success) {
        qDebug() << "Decomposition failed" ;
    }
    else
    {
        qDebug() << "Decomposition worked!" ;
    }

    // Solution vector
    VectorXd x;

    // Solve
    x = chol.solve(A.transpose() * b);

    printSolution(x);
}

void setUpPartialDerivativesSystem(SpMat & A,  VectorXd & b)
{
    // Triplets init
    vector<T>  * tripletList;
    tripletList = new vector<T>;
    tripletList->reserve(lenght*4);

    // Resize b to number of unknowns (in this case, = lenght)
    b.resize(lenght);
    b.setZero();

    // Set up the constraints
    // For every cell in the field
    for(int i = 0; i < lenght; i++)
    {
        // c_i
        int c_i = i;
        // c_j
        int c_j = i+1;

        // Handle Boundary
        // If I am on the right edge, then:
        if(i==lenght-1)
        {
            c_j = c_i;
        }

        // Add smooth constraints to A (check partial derivatives)
        // A(ci,ci) = 2
        tripletList->push_back(T(c_i,c_i,2));
        // A(cj,cj) = 2
        tripletList->push_back(T(c_j,c_j,2));
        // A(ci,cj) = -2
        tripletList->push_back(T(c_i,c_j,-2));
        // A(cj,ci) = -2
        tripletList->push_back(T(c_j,c_i,-2));

        // On b (it's equal to 0 in this case, pointless)
        b(c_i) += 0;
        b(c_j) += 0;

        // Add scalar constraints to A and b (check partial derivatives)
        if(constrained[i])
        {
            tripletList->push_back(T(c_i,c_i,2*1000000));
            b(c_i) += 2 * 1000000 * field[i];
        }
    }

    // Resize A before setting it from triplets (A is empty and not created at this point)
    A.resize(lenght,lenght);
    A.reserve(VectorXd::Constant(lenght,2));
    A.setFromTriplets(tripletList->begin(),tripletList->end());
    A.makeCompressed();
}


void solveWithPartialDerivatives()
{
    qDebug() << "Solving with partial derivatives";

    // A and b
    SpMat A;
    VectorXd b;

    // Set up system
    setUpPartialDerivativesSystem(A,b);


    // Cholesky Decomposition
    SimplicialCholesky<SpMat> chol(A);
    //ConjugateGradient<SpMat> cg(A_final);
    //cg.setTolerance(0.0001);

    // Check success
    if(chol.info()!=Success) {
        qDebug() << "Decomposition failed" ;
    }
    else
    {
        qDebug() << "Decomposition worked!" ;
    }

    // Solution vector
    VectorXd x;

    // Solve
    x = chol.solve(b);

    printSolution(x);

}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // Set up data structures
    setUp();

    // Add constraints
    addConstraints();

    // Solve Normal
    solveWithNormalEquation();
    //solveWithPartialDerivatives();

    return a.exec();
}



